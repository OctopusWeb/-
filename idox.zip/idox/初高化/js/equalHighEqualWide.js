(function (lib, img, cjs, ss) {

var p; // shortcut to reference prototypes

// library properties:
lib.properties = {
	width: 720,
	height: 400,
	fps: 24,
	color: "#000000",
	manifest: []
};



// symbols:



(lib.LC3812_97453_696861 = function() {
	this.initialize();

	// D2
	this.text = new cjs.Text("阴影", "20px 'Microsoft YaHei'", "#FFFFFF");
	this.text.lineHeight = 22;
	this.text.lineWidth = 42;
	this.text.setTransform(17.6,-12.9);

	this.text_1 = new cjs.Text("S", "italic bold 30px 'Times New Roman'", "#FFFFFF");
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 18;
	this.text_1.setTransform(0,-21.8);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-21.8,63.3,39.4);


(lib.LC3812_97453_69686 = function() {
	this.initialize();

	// D2
	this.text = new cjs.Text("1", "bold 20px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 22;
	this.text.lineWidth = 10;
	this.text.setTransform(17.6,-12.9);

	this.text_1 = new cjs.Text("S", "italic bold 30px 'Times New Roman'", "#FFFFFF");
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 18;
	this.text_1.setTransform(0,-21.8);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-21.8,31.6,37.3);


(lib.LC3812_95550_64777 = function() {
	this.initialize();

	// C4
	this.text = new cjs.Text("等底", "30px 'Microsoft YaHei'", "#FFFFFF");
	this.text.lineHeight = 32;
	this.text.lineWidth = 100;
	this.text.setTransform(0,-39.2);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-39.2,104,43.6);


(lib.LC3812_74916_76553 = function() {
	this.initialize();

	// C3
	this.text = new cjs.Text("1", "bold 14px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 16;
	this.text.lineWidth = 8;
	this.text.setTransform(11.6,-9.8);

	this.text_1 = new cjs.Text("S", "italic bold 20px 'Times New Roman'", "#FFFFFF");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 18;
	this.text_1.setTransform(0,-16.3);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-16.3,23.2,26.2);


(lib.LC3812_73896_52779 = function() {
	this.initialize();

	// D3
	this.text = new cjs.Text("2", "bold 20px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 22;
	this.text.lineWidth = 10;
	this.text.setTransform(17.6,-12.9);

	this.text_1 = new cjs.Text("S", "italic bold 30px 'Times New Roman'", "#FFFFFF");
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 18;
	this.text_1.setTransform(0,-21.8);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-21.8,31.6,37.3);


(lib.LC3812_62594_91880 = function() {
	this.initialize();

	// C2
	this.text = new cjs.Text("2", "bold 14px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 16;
	this.text.lineWidth = 8;
	this.text.setTransform(11.6,-15.3);

	this.text_1 = new cjs.Text("S", "italic bold 20px 'Times New Roman'", "#FFFFFF");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 18;
	this.text_1.setTransform(0,-21.8);

	this.addChild(this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-21.8,23.2,26.2);


(lib.LC3812_5180_51019 = function() {
	this.initialize();

	// C6
	this.text = new cjs.Text("同高", "30px 'Microsoft YaHei'", "#FFFFFF");
	this.text.lineHeight = 32;
	this.text.lineWidth = 100;
	this.text.setTransform(20,-39.2);

	this.addChild(this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(20,-39.2,104,43.6);


(lib.aaaaaa = function() {
	this.initialize();

	// ssss
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(0,252,255,0.247)").s().p("AqsOMIMR8YIJIcTIgBAFg");
	this.shape.setTransform(68.6,-0.5);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,-91.4,137.2,181.8);


(lib.aa1 = function() {
	this.initialize();

	// D1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FF009C").ss(2,1,1).p("AgmglIBNAAIAABL");
	this.shape.setTransform(4.9,64.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#FF009C").ss(2,1,1).p("AAApKIAAhpAAAlDIAAhKAAAhIIAAhHAAAjPIAAhKAAAnLIAAhUAAAGQIAAhSAAADkIAAhQAAAK0IAAhJAAAImIAAhFAAABGIAAhN");

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-1,-70.2,10.8,140.4);


(lib.LC3812_29227_552401 = function() {
	this.initialize();

	// C1
	this.instance = new lib.LC3812_97453_696861("synched",0);
	this.instance.setTransform(-2.9,3.5,1,1,0,0,0,11.6,-0.1);

	this.text = new cjs.Text("2", "bold 30px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 32;
	this.text.lineWidth = 15;
	this.text.setTransform(80.8,-2.6);

	this.text_1 = new cjs.Text("1", "bold 30px 'Times New Roman'", "#FFFFFF");
	this.text_1.lineHeight = 32;
	this.text_1.lineWidth = 15;
	this.text_1.setTransform(80.8,-33.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,1,1).p("AhDAAICGAA");
	this.shape.setTransform(90.3,1.1,1.471,1);

	this.text_2 = new cjs.Text("S", "italic bold 30px 'Times New Roman'", "#FFFFFF");
	this.text_2.lineHeight = 32;
	this.text_2.lineWidth = 17;
	this.text_2.setTransform(100.9,-18.2);

	this.text_3 = new cjs.Text("＝", "bold 30px 'Times New Roman'", "#FFFFFF");
	this.text_3.lineHeight = 32;
	this.text_3.lineWidth = 30;
	this.text_3.setTransform(46.1,-18.2);

	this.addChild(this.text_3,this.text_2,this.shape,this.text_1,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.5,-33.9,136.1,68.6);


(lib.LC3812_29227_55240 = function() {
	this.initialize();

	// C1
	this.instance = new lib.LC3812_97453_69686("synched",0);
	this.instance.setTransform(-2.9,3.5,1,1,0,0,0,11.6,-0.1);

	this.text = new cjs.Text("＝", "bold 30px 'Times New Roman'", "#FFFFFF");
	this.text.lineHeight = 32;
	this.text.lineWidth = 30;
	this.text.setTransform(14.9,-18.2);

	this.instance_1 = new lib.LC3812_73896_52779("synched",0);
	this.instance_1.setTransform(58.3,3.5,1,1,0,0,0,11.6,-0.1);

	this.addChild(this.instance_1,this.text,this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-14.5,-18.2,92.8,37.3);


(lib.LC3812_94639_10370 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// A1
	this.instance = new lib.LC3812_29227_552401("synched",0);
	this.instance.setTransform(314.7,-40.5,1,1,0,0,0,57,-0.1);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(249).to({_off:false},0).to({alpha:1},9).to({_off:true},9).wait(2));

	// B2
	this.instance_1 = new lib.LC3812_29227_55240("synched",0);
	this.instance_1.setTransform(314.7,-103.5,1,1,0,0,0,57,-0.1);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(193).to({_off:false},0).to({alpha:1},10).to({_off:true},64).wait(2));

	// B5
	this.instance_2 = new lib.LC3812_95550_64777("synched",0);
	this.instance_2.setTransform(295.2,-135.9,1,1,0,0,0,52,0);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(82).to({_off:false},0).to({alpha:1},7).to({_off:true},178).wait(2));

	// B11
	this.instance_3 = new lib.LC3812_5180_51019("synched",0);
	this.instance_3.setTransform(359.6,-135.9,1,1,0,0,0,52,0);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(119).to({_off:false},0).to({alpha:1},11).to({_off:true},137).wait(2));

	// B12
	this.text = new cjs.Text("中点", "20px 'Microsoft YaHei'", "#FFFFFF");
	this.text.lineHeight = 22;
	this.text.lineWidth = 40;
	this.text.setTransform(12.4,-1.7);
	this.text._off = true;

	this.timeline.addTween(cjs.Tween.get(this.text).wait(25).to({_off:false},0).to({_off:true},242).wait(2));

	// B4
	this.instance_4 = new lib.LC3812_74916_76553("synched",0);
	this.instance_4.setTransform(-31,-50.8,1,1,0,0,0,11.6,0);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(161).to({_off:false},0).to({alpha:1},11).wait(45).to({startPosition:0},0).to({alpha:0},9).to({_off:true},41).wait(2));

	// B3
	this.instance_5 = new lib.LC3812_62594_91880("synched",0);
	this.instance_5.setTransform(65,-45.4,1,1,0,0,0,11.6,-0.1);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(171).to({_off:false},0).to({alpha:1},11).wait(35).to({startPosition:0},0).to({alpha:0},9).to({_off:true},41).wait(2));

	// B6
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFCC00").s().p("AgtAuQgUgTAAgbQAAgaAUgTQATgUAaABQAbgBATAUQAUATgBAaQABAbgUATQgTATgbAAQgaAAgTgTg");
	this.shape.setTransform(35.5,-2,0.494,0.494);
	this.shape._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(6).to({_off:false},0).to({_off:true},3).wait(3).to({_off:false},0).to({_off:true},3).wait(3).to({_off:false},0).to({_off:true},249).wait(2));

	// B7
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#00FCFF").ss(2,1,1).p("AAHAAIVWAAA1cAAIVaAA");
	this.shape_1.setTransform(35.5,-2.1);
	this.shape_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(58).to({_off:false},0).to({_off:true},4).wait(4).to({_off:false},0).to({_off:true},4).wait(4).to({_off:false},0).to({_off:true},193).wait(2));

	// B9
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#FFFFFF").ss(2,1,1).p("AALgUIgVAq");
	this.shape_2.setTransform(36.5,-4.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#FFFFFF").ss(2,1,1).p("AglhFIBMCL");
	this.shape_3.setTransform(33.6,-13.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#FFFFFF").ss(2,1,1).p("AhBihICDFD");
	this.shape_4.setTransform(30.6,-22.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#FFFFFF").ss(2,1,1).p("Ahdj+IC6H9");
	this.shape_5.setTransform(27.6,-31.2);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#FFFFFF").ss(2,1,1).p("Ah4laIDxK1");
	this.shape_6.setTransform(24.6,-40);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#FFFFFF").ss(2,1,1).p("AiTm2IEnNt");
	this.shape_7.setTransform(21.7,-48.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#FFFFFF").ss(2,1,1).p("AivoTIFfQn");
	this.shape_8.setTransform(18.7,-57.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#FFFFFF").ss(2,1,1).p("AjKpvIGVTf");
	this.shape_9.setTransform(15.7,-66.4);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#FFFFFF").ss(2,1,1).p("AjlrLIHLWX");
	this.shape_10.setTransform(12.7,-75.2);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#FFFFFF").ss(2,1,1).p("AkBsnIIDZP");
	this.shape_11.setTransform(9.8,-84);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#FFFFFF").ss(2,1,1).p("AkcuEII5cJ");
	this.shape_12.setTransform(6.8,-92.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},37).to({state:[{t:this.shape_3}]},1).to({state:[{t:this.shape_4}]},1).to({state:[{t:this.shape_5}]},1).to({state:[{t:this.shape_6}]},1).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[]},220).wait(2));

	// B10
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#FF009C").ss(2,1,1).p("AAAASIAAgj");
	this.shape_13.setTransform(-21.8,-3.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#FF009C").ss(2,1,1).p("AAAhzIAADn");
	this.shape_14.setTransform(-21.8,-13.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#FF009C").ss(2,1,1).p("AAAjVIAAGr");
	this.shape_15.setTransform(-21.8,-23.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#FF009C").ss(2,1,1).p("AAAk4IAAB9AAAhKIAAA3AAAAzIAAA8AAAgPIAAA5AAAEBIAAA4AAADFIAAA2AAAB9IAAA8AAAi4IAABr");
	this.shape_16.setTransform(-21.8,-33.4);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#FF009C").ss(2,1,1).p("AAAlEIAABFAAAmaIAABRAAAjwIAABAAAAisIAAA/AAABLIAABDAAAgOIAABBAAAFcIAAA/AAAEMIAAA9AAACuIAABDAAAhcIAAA9");
	this.shape_17.setTransform(-21.8,-43.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#FF009C").ss(2,1,1).p("AAAmRIAABNAAAknIAABFAAAjTIAABFAAAhwIAABEAAABiIAABLAAAG3IAABGAAAFUIAABCAAADdIAABMAAAgNIAABHAAAn8IAABc");
	this.shape_18.setTransform(-21.8,-53);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#FF009C").ss(2,1,1).p("AAAneIAABVAAApeIAABnAAAlfIAABMAAAj6IAABMAAAiDIAABKAAAgMIAABOAAAITIAABMAAAGcIAABIAAAENIAABUAAAB6IAABR");
	this.shape_19.setTransform(-21.8,-62.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#FF009C").ss(2,1,1).p("AAAorIAABdAAArAIAAByAAAmXIAABTAAAiVIAABQAAAgLIAABWAAAJvIAABSAAAHkIAABOAAAE+IAABbAAACRIAABaAAAkhIAABT");
	this.shape_20.setTransform(-21.8,-72.7);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#FF009C").ss(2,1,1).p("AAAsjIAAB+AAAp4IAABmAAAnPIAABaAAAlIIAABZAAACpIAABhAAAgLIAABeAAALLIAABZAAAIsIAABUAAAFuIAABjAAAipIAABX");
	this.shape_21.setTransform(-21.8,-82.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#FF009C").ss(2,1,1).p("AAApXIAAhtAAAr8IAAiJAAAmmIAAhgAAAkPIAAhfAAAhfIAAhcAAAEpIAAhpAAABbIAAhlAAAOGIAAhgAAALNIAAhaAAAIJIAAhr");
	this.shape_22.setTransform(-21.8,-92.3);

	this.instance_6 = new lib.aa1("synched",0);
	this.instance_6.setTransform(-16.1,-92.3,1.304,1.304,0,0,0,4.4,0);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_13}]},102).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.instance_6}]},4).to({state:[{t:this.instance_6}]},24).to({state:[{t:this.instance_6}]},11).to({state:[]},117).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(115).to({_off:false},0).wait(24).to({startPosition:0},0).to({alpha:0},11).to({_off:true},117).wait(2));

	// B8
	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#FFFFFF").ss(2,1,1).p("A1cOKMAq5AAAI+a8Tg");
	this.shape_23.setTransform(35.5,-92.7);

	this.timeline.addTween(cjs.Tween.get(this.shape_23).to({_off:true},267).wait(2));

	// HB
	this.instance_7 = new lib.aaaaaa("synched",0);
	this.instance_7.setTransform(13,-92.5,1,1,0,0,0,114.8,0);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(232).to({_off:false},0).to({alpha:1},9).to({_off:true},26).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-102.8,-184.3,276.6,183.3);


// stage content:



(lib.equalHighEqualWide = function(mode,startPosition,loop) {
if (loop == null) { loop = false; }	this.initialize(mode,startPosition,loop,{step1:0,step2:53,step3:97,step4:134,step5:212,step6:246});

	// A1
	this.instance = new lib.LC3812_94639_10370("synched",0);
	this.instance.setTransform(306.7,268.9,1,1,0,0,0,105.3,-0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(267));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(458.6,285,276.6,183.3);

})(equalHighEqualWide = equalHighEqualWide||{}, images = images||{}, createjs = createjs||{}, ss = ss||{});
var equalHighEqualWide, images, createjs, ss;